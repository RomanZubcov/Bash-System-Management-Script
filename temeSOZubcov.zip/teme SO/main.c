#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <dirent.h>

void copy_file(const char *src_path, const char *dst_path) {
FILE *src_file = fopen(src_path, "rb");
if (src_file == NULL) {
	perror("Cannot open source file");
	exit(EXIT_FAILURE);
}

FILE *dst_file = fopen(dst_path, "wb");
if (dst_file == NULL) {
	perror("Cannot create destination file");
	fclose(src_file);
	exit(EXIT_FAILURE);
}

char buffer[1024];
size_t size;
while ((size = fread(buffer, 1, sizeof(buffer), src_file)) > 0) {
	if (fwrite(buffer, 1, size, dst_file) != size) {
		perror("Cannot write to destination file");
		fclose(src_file);
		fclose(dst_file);
		exit(EXIT_FAILURE);
	}
}

fclose(src_file);
fclose(dst_file);
}

void copy_dir(const char *src_path, const char *dst_path) {
DIR *src_dir = opendir(src_path);
if (src_dir == NULL) {
	perror("Cannot open source directory");
	exit(EXIT_FAILURE);
}

if (mkdir(dst_path, 0755) == -1) {
	perror("Cannot create destination directory");
	closedir(src_dir);
	exit(EXIT_FAILURE);
}

struct dirent *entry;
while ((entry = readdir(src_dir)) != NULL) {
	if (entry->d_type == DT_DIR) {
		if (strcmp(entry->d_name, ".") == 0 || strcmp(entry->d_name, "..") == 0) {
			continue;
		}

		char *src_subpath = malloc(strlen(src_path) + strlen(entry->d_name) + 2);
		sprintf(src_subpath, "%s/%s", src_path, entry->d_name);

		char *dst_subpath = malloc(strlen(dst_path) + strlen(entry->d_name) + 2);
		sprintf(dst_subpath, "%s/%s", dst_path, entry->d_name);

		copy_dir(src_subpath, dst_subpath);

		free(src_subpath);
		free(dst_subpath);
	}
	else if (entry->d_type == DT_REG) {
		char *src_subpath = malloc(strlen(src_path) + strlen(entry->d_name) + 2);
		sprintf(src_subpath, "%s/%s", src_path, entry->d_name);

		char *dst_subpath = malloc(strlen(dst_path) + strlen(entry->d_name) + 2);
		sprintf(dst_subpath, "%s/%s", dst_path, entry->d_name);

		struct stat st;
		if (stat(src_subpath, &st) == -1) {
			perror("Cannot get file status");
			free(src_subpath);
			free(dst_subpath);
			continue;
		}

		if (st.st_size < 500) {
			copy_file(src_subpath, dst_subpath);
			chmod(dst_subpath, st.st_mode & 0444);
		}
		else {
			if (symlink(src_subpath, dst_subpath) == -1) {
				perror("Cannot create symbolic link");
			}
			else {
				chmod(dst_subpath, st.st_mode);
			}
		}



		free(src_subpath);
		free(dst_subpath);

		}
	}
}

int main(int argc, char *argv[]) {

//argc numarul de argumente
//argv[0] --runme
//argv[1] --sursa
//argv[2] --destinatie


if (argc != 3) {
	fprintf(stderr, "Usage: %s <src_dir> <dst_dir>\n", argv[0]);
	exit(EXIT_FAILURE);
}

copy_dir(argv[1], argv[2]);

return 0;
}

